<!-- =========================================================================================
	File Name: FullPage.vue
	Description: Full page layout
	----------------------------------------------------------------------------------------
	Item Name: Vuesax Admin - VueJS Dashboard Admin Template
	Version: 1.1
	Author: Pixinvent
	Author URL: hhttp://www.themeforest.net/user/pixinvent
========================================================================================== -->


<template>
	<div class="layout--full-page">
		<router-view></router-view>
	</div>
</template>