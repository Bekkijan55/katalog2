<!-- =========================================================================================
	File Name: Login.vue
	Description: Login Page
	----------------------------------------------------------------------------------------
	Item Name: Vuesax Admin - VueJS Dashboard Admin Template
	Version: 1.1
	Author: Pixinvent
	Author URL: hhttp://www.themeforest.net/user/pixinvent
========================================================================================== -->


<template>
  <div class="h-screen flex w-full bg-img">
    <div class="vx-col sm:w-1/2 md:w-1/2 lg:w-3/4 xl:w-3/5 mx-auto self-center">
      <vx-card>
        <div slot="no-body" class="full-page-bg-color">
          <div class="vx-row">
            <div class="vx-col hidden sm:hidden md:hidden lg:block lg:w-1/2 mx-auto self-center">
              <img src="@/assets/images/pages/login.png" alt="login" class="mx-auto">
            </div>
            <div class="vx-col sm:w-full md:w-full lg:w-1/2 mx-auto self-center bg-white pb-10">
              <div class="p-8">
                <div class="vx-card__title mb-8">
                  <h4 class="mb-4">Login</h4>
                  <p>Welcome back, please login to your account.</p>
                </div>
                <vs-input type="email" icon="icon icon-user" icon-pack="feather" label-placeholder="Email"
                          v-model="user.email" class="w-full mb-6 no-icon-border"/>
                <vs-input type="password" icon="icon icon-lock" icon-pack="feather" label-placeholder="Password"
                          v-model="user.password" class="w-full mb-4 no-icon-border"/>
                <div class="flex flex-wrap justify-between my-5">
                  <vs-checkbox v-model="checkBox1" class="mb-3">Remember Me</vs-checkbox>
                  <!--<router-link to="/pages/forgot-password">Forgot Password?</router-link>-->
                </div>
                <!--<vs-button  type="border" to="/register">Register</vs-button>-->
                <vs-button class="float-right" @click="submit">Login</vs-button>


                <!--<vs-divider position="center" class="my-8"></vs-divider>-->

                <!--<div class="social-login mb-4 flex flex-wrap justify-between">
                  <span>Or Login With</span>
                  <div class="social-login-buttons flex">
                    <vs-button color="#1551b1" class="mr-4 px-8" icon="icon icon-facebook" icon-pack="feather"></vs-button>
                    <vs-button color="#00aaff" class="px-8" icon="icon icon-twitter" icon-pack="feather"></vs-button>
                  </div>
                </div>-->
              </div>
            </div>
          </div>
        </div>
      </vx-card>
    </div>
  </div>
</template>

<script>
 /* import { setToken} from '../../utils/auth'
  import {login} from '../../api/authentication'*/
 import {mapGetters} from "vuex";

  export default {
    data() {
      return {
        user: {
          email: null,
          password: null
        },
        checkBox1: false
      }
    },
    methods: {
      submit() {
       /* login(this.user).then(response => {
          console.log('sdfjk')
          this.$store.commit('SET_TOKEN', response.data.authorization)
          setToken(response.data.authorization)
          /!*setTimeout(() => {
           VueNotifications.success({message: 'Login success!'});
           }, 1000)*!/

          this.$router.push({path: '/dashboard'})
        })*/
        this.$store.dispatch("LoginUser", this.user).then(() => {
          this.$router.push({path: '/'})
        });
      }
    }
  }
</script>