<template>
  <vx-card>
    <h1>Upload excel</h1>
    <form @submit.prevent="sendFile" enctype="multipart/form-data">
      <input type="file" ref="file" @change="checkFile">
      <vs-button type="filled" size="small" color="primary">Upload</vs-button>
    </form>
  </vx-card>
</template>

<script>
import { sendExcel } from "../../../api/katalog";
export default {
  data() {
    return {
      file: "",
      ex: {
        excel: null
      },
      fileToUpload: null
    };
  },
  mounted() {},

  methods: {
    checkFile(e) {
      var fileReader = new FileReader();
      fileReader.readAsDataURL(e.target.files[0]);

      fileReader.onload = e => {
        this.ex.excel = e.target.result;
      };
    },

    sendFile() {
      sendExcel(this.ex)
        .then(res => {
          console.log(res);
        })
        .catch(err => console.log(err));
    }
  }
};
</script>

<style>
</style>
