export default {
    'name': 'Ism',
    'email': 'Email',
    'activeness': 'Faollik',
    'time': 'Vaqt',
    'enterTime': 'Kirish vaqti',
    'outTime': 'Chiqish vaqti'
}
