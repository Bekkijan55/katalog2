export default {
    'name': 'Name',
    'email': 'Email',
    'activeness': 'Activeness',
    'time': 'Time',
    'enterTime': 'Entering Time',
    'outTime': 'Out Time'
}
