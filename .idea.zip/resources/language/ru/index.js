export default {
    'name': 'Имя',
    'email': 'Email',
    'activeness': 'Активность',
    'time': 'Время',
    'enterTime': 'Время входа',
    'outTime': 'Время выхода'
}
