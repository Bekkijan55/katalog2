import en from './en';
import ru from './ru';
import uz from './uz';

export default {
    en: {
        message: en
    },
    ru: {
        message: ru
    },
    uz: {
        message: uz
    }
}
