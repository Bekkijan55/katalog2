<?php /* C:\OSPanel\domains\katalog2\resources\views/app.blade.php */ ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Laravel</title>

    <!-- Fonts -->
    
    

    <link href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>

<noscript>
    <strong>We're sorry but Vuesax - Vuejs Admin Dashboard Template doesn't work properly without JavaScript enabled. Please enable it to continue.</strong>
</noscript>
<div id="app"></div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
