<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Resources\VedmostResource;
use App\Vedmost;

class Katalog extends Model
{
 
}
