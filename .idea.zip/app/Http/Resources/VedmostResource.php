<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VedmostResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
       // return parent::toArray($request);
       return [
           'id' => $this->id,
           'good' => $this->good_name,
           'unit' => $this->unit,
           'amount' => $this->amount,
           'price' => $this->price,
           'summa' => $this->summa,
           'passed' => $this->passed
       ];
    }
}
